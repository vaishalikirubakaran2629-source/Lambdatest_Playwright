import{test, expect} from '@playwright/test'

test.beforeEach(async ({ page }) => {
   
    page.on('request', request => console.log('Request:', request.url()));
    page.on('response', response => console.log('Response:', response.status(), response.url()));
  });

  test.afterEach(async({page})=>{
    const wsEndpoint = page.context()._connection.url();
const testIdMatch = wsEndpoint.match(/\/([a-z0-9\-]+)$/i);
if (testIdMatch) console.log(`LambdaTest Test ID for "${testInfo.title}" on ${testInfo.project.name}: ${testIdMatch[1]}`);

  })

test('Scenario 1', async({page})=>{
    
    let msg ='Welcome to LambdaTest'
    await page.goto('https://www.lambdatest.com/selenium-playground')
    await page.getByRole('link',{name:'Simple Form Demo'}).click()
    await page.getByPlaceholder('Please enter your Message').fill(msg)
    await page.locator('[id="showInput"]').click()
      const message=await page.locator('[id="message"]')
    await expect(message).toContainText('Welcome to LambdaTest')

})
  test('Drag slider "Default value 15" to 95', async ({ page }) => {
 
 await page.goto('https://www.lambdatest.com/selenium-playground', { waitUntil: 'domcontentloaded' });

 await page.locator('text=Drag & Drop Sliders').first().click();

 await page.waitForSelector('input[type="range"]');

 const rangeHandles = await page.$$('input[type="range"]');
 let targetHandle = null;
 for (const handle of rangeHandles) {
   const v = await handle.evaluate((el) => el.value);
   if (String(v) === '15') { 
     targetHandle = handle;
     break;
   }
 }
 if (!targetHandle) {
   throw new Error('Unable to find a slider with default value 15 on the page.');
 }
 
 await targetHandle.evaluate((el, value) => {
   el.value = value;
    el.dispatchEvent(new Event('input', { bubbles: true }));
   el.dispatchEvent(new Event('change', { bubbles: true }));
 }, '95');
 
 const display = page.locator('#rangeSuccess');
 try {
   await expect(display).toHaveText('95', { timeout: 3000 });
 } catch (err) {
   
   const newValue = await targetHandle.evaluate((el) => el.value);
   expect(newValue).toBe('95');
 }
});

test('LambdaTest Input Form Submit scenario', async ({ page }) => {
 
  await page.goto('https://www.lambdatest.com/selenium-playground');

   await page.locator('text=Input Form Submit').click();

  await page.getByRole('button', { name: 'Submit' }).click();

  //const validationMessage = page.locator('small:has-text("Please fill in the fields")');
  // await expect(validationMessage.first()).toBeVisible();

  await page.fill('input[name="name"]', 'John Doe');
  await page.fill('[placeholder="Email"]', 'johndoe@example.com');
  await page.fill('input[name="password"]', 'Password123');
  await page.fill('input[name="company"]', 'Example Inc');
  await page.fill('input[name="website"]', 'https://example.com');
  await page.fill('input[name="city"]', 'New York');

    await page.selectOption('select[name="country"]', { label: 'United States' });

  await page.fill('[placeholder="State"]', 'NY');
  await page.fill('[id="inputAddress1"]', '123 Main Street');
  await page.fill('[id="inputAddress2"]', 'highland');
  await page.fill('input[name="zip"]', '10001');
  
  await page.getByRole('button',{name:'Submit'}).click();

  const successMessage = page.locator('.success-msg'); 
  await expect(successMessage).toHaveText("Thanks for contacting us, we will get back to you shortly.");
});







    
